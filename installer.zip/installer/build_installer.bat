@echo off
setlocal

rem Localise le compilateur Inno Setup 6 (ISCC.exe)
set "ISCC="
for %%P in (
    "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    "C:\Program Files\Inno Setup 6\ISCC.exe"
    "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
) do (
    if exist "%%~P" set "ISCC=%%~P"
)

rem Fallback : cherche dans le PATH
if not defined ISCC (
    where ISCC >nul 2>nul
    if not errorlevel 1 set "ISCC=ISCC"
)

if not defined ISCC (
    echo [ERREUR] Inno Setup 6 n'est pas installe sur cette machine.
    echo Téléchargez-le depuis https://jrsoftware.org/isinfo.php puis relancez ce script.
    exit /b 1
)

echo Compilation de l'installeur avec : %ISCC%
"%ISCC%" "DeltaGame Installer.iss"
if errorlevel 1 (
    echo [ERREUR] Echec de la compilation de l'installeur.
    exit /b 1
)

echo.
echo Installeur genere dans : installer\output\DeltaGame-Setup.exe
endlocal
