; Delta Game Launcher - Installateur Inno Setup
;
; Cet installeur s'adapte au PC du destinataire :
;  - Aucun chemin absolu du PC source n'est gravé dans l'installeur.
;  - Les jeux et la musique sont détectés automatiquement au premier lancement
;    (le scanner Steam lit le registre du PC cible et régénère games.json).
;  - L'installation se fait dans le dossier choisi par l'utilisateur.
;
; Compilation : ISCC.exe "DeltaGame Installer.iss"  (ou build_installer.bat)

#define MyAppName "Delta Game Launcher"
#define MyAppVersion "1.0"
#define MyAppPublisher "Delta"
#define MyAppExeName "DeltaGame.exe"

[Setup]
AppId={{8A7F3C2D-4E11-4D9A-B2C3-5D1E6F7A8B9C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Delta Game
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=no
OutputDir=output
OutputBaseFilename=DeltaGame-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; Pas besoin de droits administrateur : on peut installer en mode per-user.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
SetupLogging=yes
; Détection d'une installation déjà présente pour mise à jour sans perte de données.
UninstallDisplayIcon={app}\{#MyAppExeName}
CloseApplications=no

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Files]
; Binaire principal
Source: "..\DeltaGame.exe"; DestDir: "{app}"; Flags: ignoreversion

; Ressources (musique et icônes) - chemins relatifs, adaptés au dossier d'installation
Source: "..\music\*";    DestDir: "{app}\music"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\icon\*";     DestDir: "{app}\icon";  Flags: ignoreversion recursesubdirs createallsubdirs

; Fichier de config minimal (régénéré par l'app au lancement si besoin)
Source: "games-template.json"; DestDir: "{app}"; DestName: "games.json"; Flags: ignoreversion onlyifdoesntexist

[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
Name: "{group}\{#MyAppName}";       Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Désinstaller {#MyAppName}"; Filename: "{uninstallexe}"

[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis :"; Flags: checkedonce

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Lancer Delta Game Launcher"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Supprime aussi les données générées (jeux détectés, config, journaux) lors de la désinstallation
Type: files; Name: "{app}\games.json"
Type: files; Name: "{app}\deltagame.cfg"
Type: files; Name: "{app}\debug.log"
Type: filesandordirs; Name: "{app}\music"
Type: filesandordirs; Name: "{app}\icon"
